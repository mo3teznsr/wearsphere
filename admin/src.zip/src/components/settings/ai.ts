export const AI = [
    {
      name: 'openai',
      value:'openai',
    }, 
  ];
  