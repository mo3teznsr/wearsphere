export const faq = [
  {
    titleKey: "faq-one-title",
    contentKey: "faq-one-content",
  },
  {
    titleKey: "faq-two-title",
    contentKey: "faq-two-content",
  },
  {
    titleKey: "faq-three-title",
    contentKey: "faq-three-content",
  },
  {
    titleKey: "faq-four-title",
    contentKey: "faq-four-content",
  },
];