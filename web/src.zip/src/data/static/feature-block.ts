export const featureBlock = [
  {
    id: 1,
    icon: "/assets/images/feature/saving.svg",
    title: "feature-title-one",
    description: "feature-description-one",
  },
  {
    id: 2,
    icon: "/assets/images/feature/risk-free.svg",
    title: "feature-title-two",
    description: "feature-description-two",
  },
  {
    id: 3,
    icon: "/assets/images/feature/delivery.svg",
    title: "feature-title-three",
    description: "feature-description-three",
  },
  {
    id: 4,
    icon: "/assets/images/feature/product.svg",
    title: "feature-title-four",
    description: "feature-description-four",
  },
];
