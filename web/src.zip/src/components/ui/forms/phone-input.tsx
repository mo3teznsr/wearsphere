import 'react-phone-input-2/lib/bootstrap.css';
export { default } from 'react-phone-input-2';