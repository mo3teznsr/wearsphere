export const formatCategories = () => {};
